import { getDbClient, isMockMode, mockOrders, setMockOrders, mockProducts, mockCustomers, enqueueSync, mockFinancial, setMockFinancial, mockProfiles } from '../supabaseClient';
import { adjustStock } from './products';

export async function getOrders(tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    const ordersWithJoins = mockOrders.filter(o => o.tenant_id === tenantId).map(order => {
      const customer = mockCustomers.find(c => c.id === order.customer_id) || { name: 'Cliente Desconhecido' };
      const product = mockProducts.find(p => p.id === order.product_id) || { name: 'Produto Desconhecido', stock_quantity: 0 };
      const mockStages = [
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17001', name: 'A produzir', color: '#94a3b8' },
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17002', name: 'Em produção', color: '#3b82f6' },
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17003', name: 'Manuseio', color: '#a855f7' },
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17004', name: 'Em revisão', color: '#eab308' },
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17005', name: 'Expedição', color: '#f97316' },
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17006', name: 'Concluído', color: '#10b981' },
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17007', name: 'Estoque', color: '#14b8a6' },
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17008', name: 'Atrasado', color: '#ef4444' }
      ];
      const stage = mockStages.find(s => s.id === order.stage_id) || mockStages.find(s => s.name === order.status) || mockStages[0];
      return {
        ...order,
        customer,
        product,
        stage
      };
    });
    ordersWithJoins.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    return { data: ordersWithJoins, error: null };
  }
  
  const { data, error } = await getDbClient()
    .from('orders')
    .select('*, customer:customers(*), product:products(*), stage:order_stages(*)')
    .eq('tenant_id', tenantId)
    .order('created_at', { ascending: false });
  return { data, error };
}

export async function createOrder(order: any) {
  const newOrder = {
    id: order.id || (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2)),
    tenant_id: order.tenant_id || 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_number: mockOrders.length + 1001,
    created_at: new Date().toISOString(),
    ...order
  };
  
  if (isMockMode) {
    mockOrders.unshift(newOrder);
    await adjustStock(newOrder.product_id, -newOrder.boxes_count, 'PEDIDO', `Pedido #${newOrder.order_number} cadastrado`, newOrder.tenant_id);
    const product = mockProducts.find(p => p.id === newOrder.product_id);
    const amount = (product ? product.price * newOrder.print_run : 0) + newOrder.freight_value;
    const customer = mockCustomers.find(c => c.id === newOrder.customer_id);
    
    const newFin = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      tenant_id: newOrder.tenant_id,
      order_id: newOrder.id,
      type: 'RECEITA',
      amount,
      status: 'PENDENTE',
      description: `Venda ${customer ? customer.name : 'Cliente'} #${newOrder.order_number}`,
      due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      payment_date: null,
      created_at: new Date().toISOString()
    };
    mockFinancial.unshift(newFin);
    await enqueueSync(newOrder.tenant_id, 'ORDER', newOrder.id, 'CREATE');
    return { data: newOrder, error: null };
  }
  
  let orderToInsert = { ...order };
  if (!orderToInsert.product_id) {
    // Busca o primeiro produto disponível para satisfazer a FK NOT NULL da tabela orders
    const { data: existingProd } = await getDbClient()
      .from('products')
      .select('id')
      .limit(1)
      .maybeSingle();

    if (existingProd?.id) {
      orderToInsert.product_id = existingProd.id;
    } else {
      // Se não houver produtos cadastrados, cria um produto genérico padrão
      const { data: newProd } = await getDbClient()
        .from('products')
        .insert([{
          tenant_id: orderToInsert.tenant_id || 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
          name: 'Produto Sob Encomenda / Geral',
          description: '[CATEGORIA:PERSONALIZADA]',
          price: 0,
          stock_quantity: 0
        }])
        .select('id')
        .single();
      if (newProd?.id) {
        orderToInsert.product_id = newProd.id;
      }
    }
  }
  
  const { data, error } = await getDbClient().from('orders').insert([orderToInsert]).select().single();
  if (!error && data) {
    if (order.product_id) {
      await adjustStock(data.product_id, -data.boxes_count, 'PEDIDO', `Pedido #${data.order_number} cadastrado`, data.tenant_id);
    }
    
    const { data: prod } = await getDbClient().from('products').select('price').eq('id', data.product_id).single();
    const { data: cust } = await getDbClient().from('customers').select('name').eq('id', data.customer_id).single();
    const amount = ((prod ? prod.price : 0) * data.print_run) + data.freight_value;
    
    await getDbClient().from('financial_transactions').insert([{
      tenant_id: data.tenant_id,
      order_id: data.id,
      type: 'RECEITA',
      amount,
      status: 'PENDENTE',
      description: `Venda ${cust ? cust.name : 'Cliente'} #${data.order_number}`,
      due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    }]);
    
    await enqueueSync(data.tenant_id, 'ORDER', data.id, 'CREATE');
  }
  return { data, error };
}

export async function updateOrder(id: string, updates: any) {
  if (isMockMode) {
    const updatedMocks = mockOrders.map(o => o.id === id ? { ...o, ...updates } : o);
    setMockOrders(updatedMocks);
    const updated = mockOrders.find(o => o.id === id);
    if (updated) {
      if (updates.status === 'Pago') {
        const updatedFinancialMocks = mockFinancial.map(f => f.order_id === id ? { ...f, status: 'CONCILIADO', payment_date: new Date().toISOString().split('T')[0] } : f);
        setMockFinancial(updatedFinancialMocks);
      }
      await enqueueSync(updated.tenant_id, 'ORDER', id, 'UPDATE');
    }
    return { data: updated, error: null };
  }
  
  const { data, error } = await getDbClient().from('orders').update(updates).eq('id', id).select().single();
  if (!error && data) {
    if (updates.status === 'Pago') {
      await getDbClient()
        .from('financial_transactions')
        .update({ status: 'CONCILIADO', payment_date: new Date().toISOString().split('T')[0] })
        .eq('order_id', id);
    }
    await enqueueSync(data.tenant_id, 'ORDER', data.id, 'UPDATE');
  }
  return { data, error };
}

export async function deleteOrder(id: string) {
  if (isMockMode) {
    const updatedMocks = mockOrders.filter(o => o.id !== id);
    setMockOrders(updatedMocks);
    mockOrderItems = mockOrderItems.filter(i => i.order_id !== id);
    return { data: null, error: null };
  }

  // Deleta itens do pedido
  await getDbClient().from('order_items').delete().eq('order_id', id);
  // Deleta transações financeiras se houver
  await getDbClient().from('financial_transactions').delete().eq('order_id', id);
  // Deleta o registro em orders
  const { data, error } = await getDbClient().from('orders').delete().eq('id', id).select().single();
  return { data, error };
}

// Etapas do Kanban
export async function getOrderStages(tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    const mockStages = [
      { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17001', tenant_id: tenantId, name: 'A produzir', color: '#94a3b8', sequence: 1 },
      { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17002', tenant_id: tenantId, name: 'Em produção', color: '#3b82f6', sequence: 2 },
      { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17003', tenant_id: tenantId, name: 'Manuseio', color: '#a855f7', sequence: 3 },
      { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17004', tenant_id: tenantId, name: 'Em revisão', color: '#eab308', sequence: 4 },
      { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17005', tenant_id: tenantId, name: 'Expedição', color: '#f97316', sequence: 5 },
      { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17006', tenant_id: tenantId, name: 'Concluído', color: '#10b981', sequence: 6 },
      { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17007', tenant_id: tenantId, name: 'Estoque', color: '#14b8a6', sequence: 7 },
      { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17008', tenant_id: tenantId, name: 'Atrasado', color: '#ef4444', sequence: 8 }
    ];
    return { data: mockStages, error: null };
  }
  const { data, error } = await getDbClient()
    .from('order_stages')
    .select('*')
    .eq('tenant_id', tenantId)
    .order('sequence', { ascending: true });
  return { data, error };
}

export async function createOrderStage(stage: any) {
  if (isMockMode) {
    return { data: { id: Math.random().toString(), ...stage }, error: null };
  }
  const { data, error } = await getDbClient()
    .from('order_stages')
    .insert([stage])
    .select()
    .single();
  return { data, error };
}

export async function updateOrderStage(id: string, updates: any) {
  if (isMockMode) {
    return { data: { id, ...updates }, error: null };
  }
  const { data, error } = await getDbClient()
    .from('order_stages')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  return { data, error };
}

export async function deleteOrderStage(id: string) {
  if (isMockMode) {
    return { data: null, error: null };
  }
  const { data, error } = await getDbClient()
    .from('order_stages')
    .delete()
    .eq('id', id)
    .select()
    .single();
  return { data, error };
}

// Permissões por Perfil



// --- ITENS DE PEDIDO (ORDER ITEMS) ---

export interface OrderItem {
  id: string;
  tenant_id: string;
  order_id: string;
  product_id: string | null;
  item_type: 'PRODUTO' | 'SERVICO';
  name: string;
  item_index: number;
  friendly_id: string;
  measure: string | null;
  print_run: number;
  boxes_count: number;
  quantity_per_box?: number | null;
  packaging_type: 'CAIXA' | 'PACOTE';
  over_short_quantity: number;
  shortage_quantity?: number;
  courtesy_quantity?: number;
  expedition_notes?: string | null;
  status: string;
  production_sector: string;
  stage_id: string | null;
  machine_id: string | null;
  handling_team_id: string | null;
  physical_location: string | null;
  notes: string | null;
  adjustment_resolved?: boolean;
  resolved_by_item_id?: string | null;
  applied_adjustment_id?: string | null;
  adjusted_quantity_math?: string | null;
  adjusted_production_quantity?: number | null;
  last_operator_id?: string | null;
  created_at: string;
  updated_at: string;
  // joined fields
  product?: any;
  stage?: any;
}

let mockOrderItems: any[] = [
  {
    id: 'i00184c8-3e4b-4b14-87cf-45ef42d17i01',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_id: 'a00184c8-3e4b-4b14-87cf-45ef42d17c01',
    product_id: '800184c8-3e4b-4b14-87cf-45ef42d17c01',
    item_type: 'PRODUTO',
    name: 'Caixa Kraft para Bombom (P)',
    item_index: 1,
    friendly_id: 'PV-1001/1',
    measure: '15x10x5 cm',
    print_run: 5000,
    boxes_count: 10,
    packaging_type: 'CAIXA',
    over_short_quantity: 100,
    status: 'A produzir',
    production_sector: 'Impressão',
    stage_id: 'e00184c8-3e4b-4b14-87cf-45ef42d17001',
    physical_location: 'Máquina Flexo 1',
    notes: 'Logo centralizada na tampa.',
    created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'i00184c8-3e4b-4b14-87cf-45ef42d17i02',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_id: 'a00184c8-3e4b-4b14-87cf-45ef42d17c01',
    product_id: null,
    item_type: 'SERVICO',
    name: 'Cartão de Fundo Personalizado',
    item_index: 2,
    friendly_id: 'PV-1001/2',
    measure: '14x9 cm',
    print_run: 5000,
    boxes_count: 0,
    packaging_type: 'PACOTE',
    over_short_quantity: 0,
    status: 'A produzir',
    production_sector: 'Impressão',
    stage_id: 'e00184c8-3e4b-4b14-87cf-45ef42d17001',
    physical_location: 'Máquina Flexo 1',
    notes: 'Papel duplex 250g.',
    created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'i00284c8-3e4b-4b14-87cf-45ef42d17i03',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_id: 'a00284c8-3e4b-4b14-87cf-45ef42d17c02',
    product_id: '800284c8-3e4b-4b14-87cf-45ef42d17c02',
    item_type: 'PRODUTO',
    name: 'Sacola Duplex Branca Premium (M)',
    item_index: 1,
    friendly_id: 'PV-1002/1',
    measure: '25x30x10 cm',
    print_run: 2000,
    boxes_count: 4,
    packaging_type: 'PACOTE',
    over_short_quantity: 0,
    status: 'Em revisão',
    production_sector: 'Corte e Vinco',
    stage_id: 'e00184c8-3e4b-4b14-87cf-45ef42d17004',
    physical_location: 'Salão',
    notes: 'Aguardando aprovação de layout.',
    created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'i00284c8-3e4b-4b14-87cf-45ef42d17i04',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_id: 'a00284c8-3e4b-4b14-87cf-45ef42d17c02',
    product_id: null,
    item_type: 'SERVICO',
    name: 'Serviço de Verniz Localizado',
    item_index: 2,
    friendly_id: 'PV-1002/2',
    measure: null,
    print_run: 2000,
    boxes_count: 0,
    packaging_type: 'PACOTE',
    over_short_quantity: 0,
    status: 'Em revisão',
    production_sector: 'Corte e Vinco',
    stage_id: 'e00184c8-3e4b-4b14-87cf-45ef42d17004',
    physical_location: 'Salão',
    notes: 'Aplicar verniz apenas na logo.',
    created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
  }
];

export async function getOrderItems(orderId?: string, tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    let items = mockOrderItems.filter(item => item.tenant_id === tenantId);
    if (orderId) {
      items = items.filter(item => item.order_id === orderId);
    }
    const itemsWithJoins = items.map(item => {
      const product = mockProducts.find(p => p.id === item.product_id) || null;
      const order = mockOrders.find(o => o.id === item.order_id) || null;
      let customer = null;
      if (order) {
        customer = mockCustomers.find(c => c.id === order.customer_id) || null;
      }
      const mockStages = [
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17001', name: 'A produzir', color: '#94a3b8' },
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17002', name: 'Em produção', color: '#3b82f6' },
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17003', name: 'Manuseio', color: '#a855f7' },
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17004', name: 'Em revisão', color: '#eab308' },
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17005', name: 'Expedição', color: '#f97316' },
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17006', name: 'Concluído', color: '#10b981' },
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17007', name: 'Estoque', color: '#14b8a6' },
        { id: 'e00184c8-3e4b-4b14-87cf-45ef42d17008', name: 'Atrasado', color: '#ef4444' }
      ];
      const stage = mockStages.find(s => s.id === item.stage_id) || null;
      return {
        ...item,
        product,
        stage,
        order: order ? { ...order, customer } : null
      };
    });
    return { data: itemsWithJoins, error: null };
  }

  // Query base sem tabelas opcionais (production_machines / handling_teams podem não existir ainda)
  const baseSelect = '*, product:products(*), stage:order_stages(*), order:orders(*, customer:customers(*))';
  const fullSelect = '*, product:products(*), stage:order_stages(*), machine:production_machines(*), handling_team:handling_teams(*), order:orders(*, customer:customers(*))';

  const buildQuery = (selectStr: string) => {
    let q = getDbClient()
      .from('order_items')
      .select(selectStr)
      .eq('tenant_id', tenantId);
    if (orderId) {
      q = q.eq('order_id', orderId);
    }
    return q.order('created_at', { ascending: false });
  };

  // Tenta com JOINs completos primeiro; se falhar (tabelas ausentes), tenta sem eles
  let { data, error } = await buildQuery(fullSelect);
  if (error && (error.code === 'PGRST200' || error.message?.includes('relationship') || error.message?.includes('schema cache'))) {
    const fallback = await buildQuery(baseSelect);
    data = fallback.data;
    error = fallback.error;
  }

  return { data, error };
}


export async function createOrderItem(item: Omit<OrderItem, 'id' | 'item_index' | 'friendly_id' | 'created_at' | 'updated_at'>) {
  const tenantId = item.tenant_id || 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0';
  
  if (isMockMode) {
    const orderItemsForParent = mockOrderItems.filter(i => i.order_id === item.order_id);
    const nextIdx = orderItemsForParent.reduce((max, curr) => Math.max(max, curr.item_index), 0) + 1;
    
    const parentOrder = mockOrders.find(o => o.id === item.order_id);
    const pvRef = parentOrder ? (parentOrder.pv_number || `PV-${parentOrder.order_number}`) : 'PV-MOCK';
    
    const newItem: OrderItem = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      tenant_id: tenantId,
      order_id: item.order_id,
      product_id: item.product_id,
      item_type: item.item_type,
      name: item.name,
      item_index: nextIdx,
      friendly_id: `${pvRef}/${nextIdx}`,
      measure: item.measure,
      print_run: item.print_run,
      boxes_count: item.boxes_count,
      packaging_type: item.packaging_type,
      over_short_quantity: item.over_short_quantity,
      status: item.status || 'A produzir',
      production_sector: item.production_sector || 'Impressão',
      stage_id: item.stage_id,
      machine_id: (item as any).machine_id || null,
      handling_team_id: (item as any).handling_team_id || null,
      physical_location: item.physical_location,
      notes: item.notes,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    mockOrderItems.push(newItem);
    return { data: newItem, error: null };
  }

  const { data, error } = await getDbClient()
    .from('order_items')
    .insert([{ ...item, tenant_id: item.tenant_id || tenantId }])
    .select('*, product:products(*), stage:order_stages(*)')
    .single();

  return { data, error };
}

export async function updateOrderItem(id: string, updates: Partial<OrderItem>) {
  if (isMockMode) {
    mockOrderItems = mockOrderItems.map(item => {
      if (item.id === id) {
        return {
          ...item,
          ...updates,
          updated_at: new Date().toISOString()
        };
      }
      return item;
    });
    
    const updated = mockOrderItems.find(item => item.id === id);
    return { data: updated, error: null };
  }

  const fullSelectForUpdate = '*, product:products(*), stage:order_stages(*), machine:production_machines(*), handling_team:handling_teams(*)';
  const baseSelectForUpdate = '*, product:products(*), stage:order_stages(*)';

  let { data, error } = await getDbClient()
    .from('order_items')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select(fullSelectForUpdate)
    .single();

  // Fallback se tabelas opcionais não existem ainda
  if (error && (error.code === 'PGRST200' || error.message?.includes('relationship') || error.message?.includes('schema cache'))) {
    const fallback = await getDbClient()
      .from('order_items')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select(baseSelectForUpdate)
      .single();
    data = fallback.data;
    error = fallback.error;
  }

  return { data, error };
}

export async function getPendingAdjustment(tenantId: string, customerId: string, productId: string | null) {
  if (!customerId || !productId) return { data: null, error: null };
  
  if (isMockMode) {
    const pendingMock = mockOrderItems.find((item: any) => {
      const order = mockOrders.find(o => o.id === item.order_id);
      return (
        order &&
        order.customer_id === customerId &&
        item.product_id === productId &&
        item.status === 'Concluído' &&
        item.adjustment_resolved !== true &&
        ((item.shortage_quantity && item.shortage_quantity > 0) || (item.courtesy_quantity && item.courtesy_quantity > 0))
      );
    });
    return { data: pendingMock || null, error: null };
  }

  // Puxar itens com RLS e join do orders
  const { data, error } = await getDbClient()
    .from('order_items')
    .select('*, order:orders(*)')
    .eq('tenant_id', tenantId)
    .eq('product_id', productId)
    .eq('adjustment_resolved', false)
    .or('shortage_quantity.gt.0,courtesy_quantity.gt.0');

  if (error) {
    console.error('Erro getPendingAdjustment:', error);
    return { data: null, error };
  }

  // Filtrar localmente em JS para garantir segurança do join de orders
  if (data && data.length > 0) {
    const filtered = data.find((item: any) => item.order && item.order.customer_id === customerId);
    return { data: filtered || null, error: null };
  }

  return { data: null, error: null };
}

export async function resolvePendingAdjustment(pendingItemId: string, resolvingItemId: string) {
  if (isMockMode) {
    mockOrderItems = mockOrderItems.map((item: any) => {
      if (item.id === pendingItemId) {
        return {
          ...item,
          adjustment_resolved: true,
          resolved_by_item_id: resolvingItemId,
          updated_at: new Date().toISOString()
        };
      }
      return item;
    });
    return { success: true, error: null };
  }

  const { error } = await getDbClient()
    .from('order_items')
    .update({
      adjustment_resolved: true,
      resolved_by_item_id: resolvingItemId,
      updated_at: new Date().toISOString()
    })
    .eq('id', pendingItemId);

  return { success: !error, error };
}

export async function deleteOrderItem(id: string) {
  if (isMockMode) {
    const exists = mockOrderItems.some(item => item.id === id);
    if (!exists) return { data: null, error: { message: 'Item não encontrado.' } as any };
    mockOrderItems = mockOrderItems.filter(item => item.id !== id);
    return { data: null, error: null };
  }

  const { data, error } = await getDbClient()
    .from('order_items')
    .delete()
    .eq('id', id)
    .select()
    .single();

  return { data, error };
}

// --- ESTOQUE PERSONALIZADO, SOBRAS/FALTAS E CRÉDITOS ---

export interface CustomerProductStock {
  id: string;
  tenant_id: string;
  customer_id: string;
  product_id: string;
  quantity: number;
  created_at: string;
  updated_at: string;
  customer?: any;
  product?: any;
}

export interface OrderBalanceAdjustment {
  id: string;
  tenant_id: string;
  order_id: string;
  order_item_id: string | null;
  customer_id: string;
  product_id: string;
  ordered_quantity: number;
  produced_quantity: number;
  difference_quantity: number;
  adjustment_type: 'SOBRA' | 'FALTA';
  action_taken: 'GUARDAR_ESTOQUE_CLIENTE' | 'CREDITO_PROXIMO_PEDIDO' | 'CANCELADO_DESCONTO' | 'COBRADO_ADICIONAL' | 'REPRODUCAO_PENDENTE' | 'OUTRO';
  notes: string | null;
  created_by_name?: string | null;
  created_at: string;
  order?: any;
  order_item?: any;
  customer?: any;
  product?: any;
}

export interface CustomerStockCredit {
  id: string;
  tenant_id: string;
  customer_id: string;
  product_id: string;
  credit_type: 'CORTESIA_SOBRA' | 'PENDENCIA_ENTREGA';
  original_quantity: number;
  remaining_quantity: number;
  source_order_id: string | null;
  source_adjustment_id: string | null;
  status: 'ATIVO' | 'UTILIZADO' | 'EXPIRADO' | 'CANCELADO';
  notes: string | null;
  created_at: string;
  updated_at: string;
  customer?: any;
  product?: any;
  source_order?: any;
}

let mockCustomerProductStock: CustomerProductStock[] = [
  {
    id: 's00184c8-3e4b-4b14-87cf-45ef42d17s01',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    customer_id: 'c00184c8-3e4b-4b14-87cf-45ef42d17c01',
    product_id: '800184c8-3e4b-4b14-87cf-45ef42d17c01',
    quantity: 150,
    created_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
  }
];

let mockOrderBalanceAdjustments: OrderBalanceAdjustment[] = [
  {
    id: 'adj-1',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_id: 'a00184c8-3e4b-4b14-87cf-45ef42d17c01',
    order_item_id: 'i00184c8-3e4b-4b14-87cf-45ef42d17i01',
    customer_id: 'c00184c8-3e4b-4b14-87cf-45ef42d17c01',
    product_id: '800184c8-3e4b-4b14-87cf-45ef42d17c01',
    ordered_quantity: 5000,
    produced_quantity: 7000,
    difference_quantity: 2000,
    adjustment_type: 'SOBRA',
    action_taken: 'GUARDAR_ESTOQUE_CLIENTE',
    notes: '2.000 sacos produzidos a mais. Guardados no estoque físico para o cliente Gourmet Brasil.',
    created_at: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'adj-2',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_id: 'a00284c8-3e4b-4b14-87cf-45ef42d17c02',
    order_item_id: 'i00284c8-3e4b-4b14-87cf-45ef42d17i03',
    customer_id: 'c00284c8-3e4b-4b14-87cf-45ef42d17c02',
    product_id: '800284c8-3e4b-4b14-87cf-45ef42d17c02',
    ordered_quantity: 2000,
    produced_quantity: 1850,
    difference_quantity: -150,
    adjustment_type: 'FALTA',
    action_taken: 'CREDITO_PROXIMO_PEDIDO',
    notes: 'Falta de 150 unidades. Convertido em crédito para a Quinta do Marquês usar na próxima compra.',
    created_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'adj-3',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_id: 'a00384c8-3e4b-4b14-87cf-45ef42d17c03',
    order_item_id: 'i00284c8-3e4b-4b14-87cf-45ef42d17i03',
    customer_id: 'c00384c8-3e4b-4b14-87cf-45ef42d17c03',
    product_id: '800384c8-3e4b-4b14-87cf-45ef42d17c03',
    ordered_quantity: 1000,
    produced_quantity: 1100,
    difference_quantity: 100,
    adjustment_type: 'SOBRA',
    action_taken: 'COBRADO_ADICIONAL',
    notes: 'Excedente de 100 unidades cobrado como adicional na fatura.',
    created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
  }
];
let mockCustomerStockCredits: CustomerStockCredit[] = [
  {
    id: 'cr0184c8-3e4b-4b14-87cf-45ef42d17cr1',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    customer_id: 'c00184c8-3e4b-4b14-87cf-45ef42d17c01',
    product_id: '800184c8-3e4b-4b14-87cf-45ef42d17c01',
    credit_type: 'CORTESIA_SOBRA',
    original_quantity: 150,
    remaining_quantity: 150,
    source_order_id: 'a00184c8-3e4b-4b14-87cf-45ef42d17c01',
    source_adjustment_id: null,
    status: 'ATIVO',
    notes: 'Sobra gerada no PV-1001 e mantida na fábrica para a padaria/empresa Gourmet.',
    created_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
  }
];

// --- OPERAÇÕES: ESTOQUE PERSONALIZADO POR CLIENTE ---

export async function getCustomerProductStock(customerId?: string, productId?: string, tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    let filtered = mockCustomerProductStock.filter(s => s.tenant_id === tenantId);
    if (customerId) filtered = filtered.filter(s => s.customer_id === customerId);
    if (productId) filtered = filtered.filter(s => s.product_id === productId);
    
    const withJoins = filtered.map(s => ({
      ...s,
      customer: mockCustomers.find(c => c.id === s.customer_id) || null,
      product: mockProducts.find(p => p.id === s.product_id) || null
    }));
    return { data: withJoins, error: null };
  }

  let query = getDbClient()
    .from('customer_product_stock')
    .select('*, customer:customers(*), product:products(*)')
    .eq('tenant_id', tenantId);

  if (customerId) query = query.eq('customer_id', customerId);
  if (productId) query = query.eq('product_id', productId);

  const { data, error } = await query;
  return { data, error };
}

export async function createCustomerProductStock(stock: Omit<CustomerProductStock, 'id' | 'created_at' | 'updated_at'>) {
  const tenantId = stock.tenant_id || 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0';
  if (isMockMode) {
    const existingIdx = mockCustomerProductStock.findIndex(s => s.customer_id === stock.customer_id && s.product_id === stock.product_id);
    if (existingIdx !== -1) {
      mockCustomerProductStock[existingIdx].quantity += stock.quantity;
      mockCustomerProductStock[existingIdx].updated_at = new Date().toISOString();
      return { data: mockCustomerProductStock[existingIdx], error: null };
    }
    const newStock: CustomerProductStock = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      tenant_id: tenantId,
      customer_id: stock.customer_id,
      product_id: stock.product_id,
      quantity: stock.quantity,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    mockCustomerProductStock.push(newStock);
    return { data: newStock, error: null };
  }

  const { data, error } = await getDbClient()
    .from('customer_product_stock')
    .upsert({ ...stock, tenant_id: tenantId, updated_at: new Date().toISOString() }, { onConflict: 'customer_id, product_id' })
    .select('*, customer:customers(*), product:products(*)')
    .single();

  return { data, error };
}

export async function updateCustomerProductStock(id: string, updates: Partial<CustomerProductStock>) {
  if (isMockMode) {
    mockCustomerProductStock = mockCustomerProductStock.map(s => s.id === id ? { ...s, ...updates, updated_at: new Date().toISOString() } : s);
    const updated = mockCustomerProductStock.find(s => s.id === id);
    return { data: updated, error: null };
  }

  const { data, error } = await getDbClient()
    .from('customer_product_stock')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select('*, customer:customers(*), product:products(*)')
    .single();

  return { data, error };
}

// --- OPERAÇÕES: AJUSTES DE SALDO (SOBRAS E FALTAS) ---

export async function getOrderBalanceAdjustments(orderId?: string, customerId?: string, tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    let filtered = mockOrderBalanceAdjustments.filter(a => a.tenant_id === tenantId);
    if (orderId) filtered = filtered.filter(a => a.order_id === orderId);
    if (customerId) filtered = filtered.filter(a => a.customer_id === customerId);
    const withJoins = filtered.map(a => ({
      ...a,
      order: mockOrders.find(o => o.id === a.order_id) || null,
      customer: mockCustomers.find(c => c.id === a.customer_id) || null,
      product: mockProducts.find(p => p.id === a.product_id) || null
    }));
    return { data: withJoins, error: null };
  }

  let query = getDbClient()
    .from('order_balance_adjustments')
    .select('*, order:orders(*), order_item:order_items(*), customer:customers(*), product:products(*)')
    .eq('tenant_id', tenantId);

  if (orderId) query = query.eq('order_id', orderId);
  if (customerId) query = query.eq('customer_id', customerId);

  const { data, error } = await query.order('created_at', { ascending: false });
  return { data, error };
}

export async function createOrderBalanceAdjustment(adjustment: Omit<OrderBalanceAdjustment, 'id' | 'created_at'>) {
  const tenantId = adjustment.tenant_id || 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0';
  
  if (isMockMode) {
    const newAdj: OrderBalanceAdjustment = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      ...adjustment,
      tenant_id: tenantId,
      created_at: new Date().toISOString()
    };
    mockOrderBalanceAdjustments.push(newAdj);

    if (adjustment.action_taken === 'GUARDAR_ESTOQUE_CLIENTE' && adjustment.difference_quantity > 0) {
      await createCustomerProductStock({
        tenant_id: tenantId,
        customer_id: adjustment.customer_id,
        product_id: adjustment.product_id,
        quantity: adjustment.difference_quantity
      });
      const customerName = mockCustomers.find(c => c.id === adjustment.customer_id)?.name || 'Cliente';
      const orderNum = mockOrders.find(o => o.id === adjustment.order_id)?.order_number || 'PV';
      await adjustStock(
        adjustment.product_id,
        adjustment.difference_quantity,
        'ENTRADA',
        `[ESTOQUE_CLIENTE] Entrada de Sobra - Cliente: ${customerName} - PV: ${orderNum}`,
        tenantId
      );
    }

    if (adjustment.action_taken === 'CREDITO_PROXIMO_PEDIDO' || adjustment.action_taken === 'REPRODUCAO_PENDENTE') {
      const type = adjustment.difference_quantity > 0 ? 'CORTESIA_SOBRA' : 'PENDENCIA_ENTREGA';
      const qty = Math.abs(adjustment.difference_quantity);
      await createCustomerStockCredit({
        tenant_id: tenantId,
        customer_id: adjustment.customer_id,
        product_id: adjustment.product_id,
        credit_type: type,
        original_quantity: qty,
        remaining_quantity: qty,
        source_order_id: adjustment.order_id,
        source_adjustment_id: newAdj.id,
        status: 'ATIVO',
        notes: adjustment.notes
      });
    }

    return { data: newAdj, error: null };
  }

  const { data, error } = await getDbClient()
    .from('order_balance_adjustments')
    .insert([{ ...adjustment, tenant_id: tenantId }])
    .select('*, order:orders(*), customer:customers(*), product:products(*)')
    .single();

  if (!error && data) {
    if (data.action_taken === 'GUARDAR_ESTOQUE_CLIENTE' && data.difference_quantity > 0) {
      await createCustomerProductStock({
        tenant_id: tenantId,
        customer_id: data.customer_id,
        product_id: data.product_id,
        quantity: data.difference_quantity
      });
      
      const { data: cust } = await getDbClient().from('customers').select('name').eq('id', data.customer_id).single();
      const { data: ord } = await getDbClient().from('orders').select('order_number').eq('id', data.order_id).single();
      await adjustStock(
        data.product_id,
        data.difference_quantity,
        'ENTRADA',
        `[ESTOQUE_CLIENTE] Entrada de Sobra - Cliente: ${cust ? cust.name : 'Cliente'} - PV: ${ord ? ord.order_number : 'PV'}`,
        tenantId
      );
    }

    if (data.action_taken === 'CREDITO_PROXIMO_PEDIDO' || data.action_taken === 'REPRODUCAO_PENDENTE') {
      const type = data.difference_quantity > 0 ? 'CORTESIA_SOBRA' : 'PENDENCIA_ENTREGA';
      const qty = Math.abs(data.difference_quantity);
      await createCustomerStockCredit({
        tenant_id: tenantId,
        customer_id: data.customer_id,
        product_id: data.product_id,
        credit_type: type,
        original_quantity: qty,
        remaining_quantity: qty,
        source_order_id: data.order_id,
        source_adjustment_id: data.id,
        status: 'ATIVO',
        notes: data.notes
      });
    }
  }

  return { data, error };
}

// --- OPERAÇÕES: CRÉDITOS E PENDÊNCIAS DE ESTOQUE ---

export async function getCustomerStockCredits(customerId?: string, status?: string, tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    let filtered = mockCustomerStockCredits.filter(c => c.tenant_id === tenantId);
    if (customerId) filtered = filtered.filter(c => c.customer_id === customerId);
    if (status) filtered = filtered.filter(c => c.status === status);
    const withJoins = filtered.map(c => ({
      ...c,
      customer: mockCustomers.find(cust => cust.id === c.customer_id) || null,
      product: mockProducts.find(p => p.id === c.product_id) || null,
      source_order: mockOrders.find(o => o.id === c.source_order_id) || null
    }));
    return { data: withJoins, error: null };
  }

  let query = getDbClient()
    .from('customer_stock_credits')
    .select('*, customer:customers(*), product:products(*), source_order:orders(*)')
    .eq('tenant_id', tenantId);

  if (customerId) query = query.eq('customer_id', customerId);
  if (status) query = query.eq('status', status);

  const { data, error } = await query.order('created_at', { ascending: false });
  return { data, error };
}

export async function createCustomerStockCredit(credit: Omit<CustomerStockCredit, 'id' | 'created_at' | 'updated_at'>) {
  const tenantId = credit.tenant_id || 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0';
  
  if (isMockMode) {
    const newCredit: CustomerStockCredit = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      ...credit,
      tenant_id: tenantId,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    mockCustomerStockCredits.push(newCredit);
    return { data: newCredit, error: null };
  }

  const { data, error } = await getDbClient()
    .from('customer_stock_credits')
    .insert([{ ...credit, tenant_id: tenantId }])
    .select('*, customer:customers(*), product:products(*)')
    .single();

  return { data, error };
}

export async function updateCustomerStockCredit(id: string, updates: Partial<CustomerStockCredit>) {
  if (isMockMode) {
    mockCustomerStockCredits = mockCustomerStockCredits.map(c => c.id === id ? { ...c, ...updates, updated_at: new Date().toISOString() } : c);
    const updated = mockCustomerStockCredits.find(c => c.id === id);
    return { data: updated, error: null };
  }

  const { data, error } = await getDbClient()
    .from('customer_stock_credits')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select('*, customer:customers(*), product:products(*)')
    .single();

  return { data, error };
}

// --- INCIDENTES DE PEDIDOS (ORDER INCIDENTS) ---

export interface OrderIncident {
  id: string;
  tenant_id: string;
  order_id: string;
  order_item_id: string | null;
  category: 'PRODUCAO' | 'TRANSPORTE' | 'FINANCEIRO' | 'CLIENTE' | 'MANUSEIO' | 'OUTRO';
  description: string;
  status: 'ABERTO' | 'EM_ANALISE' | 'RESOLVIDO';
  created_by: string | null;
  resolved_by: string | null;
  created_at: string;
  resolved_at: string | null;
  updated_at: string;
  order?: any;
  order_item?: any;
  creator?: any;
  resolver?: any;
}

let mockOrderIncidents: OrderIncident[] = [
  {
    id: 'in0184c8-3e4b-4b14-87cf-45ef42d17in1',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_id: 'a00184c8-3e4b-4b14-87cf-45ef42d17c01',
    order_item_id: 'i00184c8-3e4b-4b14-87cf-45ef42d17i01',
    category: 'FINANCEIRO',
    description: 'Produção iniciada antes da confirmação do sinal financeiro pelo setor financeiro.',
    status: 'RESOLVIDO',
    created_by: 'e00284c8-3e4b-4b14-87cf-45ef42d17c02',
    resolved_by: 'e00184c8-3e4b-4b14-87cf-45ef42d17c01',
    created_at: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
    resolved_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'in0184c8-3e4b-4b14-87cf-45ef42d17in2',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_id: 'a00584c8-3e4b-4b14-87cf-45ef42d17c05',
    order_item_id: null,
    category: 'TRANSPORTE',
    description: 'Pedido enviado para cidade de destino errada (coletor leu etiqueta incorreta na triagem).',
    status: 'ABERTO',
    created_by: 'e00384c8-3e4b-4b14-87cf-45ef42d17c03',
    resolved_by: null,
    created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    resolved_at: null,
    updated_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
  }
];

export async function getOrderIncidents(orderId?: string, category?: string, status?: string, tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    let filtered = mockOrderIncidents.filter(inc => inc.tenant_id === tenantId);
    if (orderId) filtered = filtered.filter(inc => inc.order_id === orderId);
    if (category) filtered = filtered.filter(inc => inc.category === category);
    if (status) filtered = filtered.filter(inc => inc.status === status);
    
    const withJoins = filtered.map(inc => ({
      ...inc,
      order: mockOrders.find(o => o.id === inc.order_id) || null,
      order_item: mockOrderItems.find(item => item.id === inc.order_item_id) || null,
      creator: mockProfiles.find(p => p.id === inc.created_by) || null,
      resolver: mockProfiles.find(p => p.id === inc.resolved_by) || null
    }));
    return { data: withJoins, error: null };
  }

  let query = getDbClient()
    .from('order_incidents')
    .select('*, order:orders(*), order_item:order_items(*), creator:profiles!created_by(*), resolver:profiles!resolved_by(*)')
    .eq('tenant_id', tenantId);

  if (orderId) query = query.eq('order_id', orderId);
  if (category) query = query.eq('category', category);
  if (status) query = query.eq('status', status);

  const { data, error } = await query.order('created_at', { ascending: false });
  return { data, error };
}

export async function createOrderIncident(incident: Omit<OrderIncident, 'id' | 'created_at' | 'resolved_at' | 'updated_at'>) {
  const tenantId = incident.tenant_id || 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0';
  
  if (isMockMode) {
    const newInc: OrderIncident = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      ...incident,
      tenant_id: tenantId,
      resolved_at: null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    mockOrderIncidents.push(newInc);
    return { data: newInc, error: null };
  }

  const { data, error } = await getDbClient()
    .from('order_incidents')
    .insert([{ ...incident, tenant_id: tenantId }])
    .select('*, order:orders(*), order_item:order_items(*), creator:profiles!created_by(*)')
    .single();

  return { data, error };
}

export async function resolveOrderIncident(id: string, resolvedBy: string, status: 'RESOLVIDO' = 'RESOLVIDO') {
  if (isMockMode) {
    mockOrderIncidents = mockOrderIncidents.map(inc => {
      if (inc.id === id) {
        return {
          ...inc,
          status,
          resolved_by: resolvedBy,
          resolved_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };
      }
      return inc;
    });
    const updated = mockOrderIncidents.find(inc => inc.id === id);
    return { data: updated, error: null };
  }

  const { data, error } = await getDbClient()
    .from('order_incidents')
    .update({
      status,
      resolved_by: resolvedBy,
      resolved_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    })
    .eq('id', id)
    .select('*, order:orders(*), order_item:order_items(*), creator:profiles!created_by(*), resolver:profiles!resolved_by(*)')
    .single();

  return { data, error };
}

export async function updateOrderIncident(id: string, updates: Partial<OrderIncident>) {
  if (isMockMode) {
    mockOrderIncidents = mockOrderIncidents.map(inc => {
      if (inc.id === id) {
        return {
          ...inc,
          ...updates,
          updated_at: new Date().toISOString()
        };
      }
      return inc;
    });
    const updated = mockOrderIncidents.find(inc => inc.id === id);
    return { data: updated, error: null };
  }

  const { data, error } = await getDbClient()
    .from('order_incidents')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select('*, order:orders(*), order_item:order_items(*), creator:profiles!created_by(*), resolver:profiles!resolved_by(*)')
    .single();

  return { data, error };
}

// --- OPERAÇÕES: MÁQUINAS E HISTÓRICO DE PRODUÇÃO POR SETOR ---

export interface ProductionMachine {
  id: string;
  tenant_id: string;
  name: string;
  sector: string;
  status: 'ATIVO' | 'INATIVO' | 'MANUTENCAO';
  created_at: string;
  updated_at: string;
}

export interface OrderItemSectorHistory {
  id: string;
  tenant_id: string;
  order_item_id: string;
  sector: string;
  machine_id: string | null;
  entered_at: string;
  exited_at: string | null;
  created_at: string;
  machine?: any;
}

export interface ProductionSector {
  id: string;
  tenant_id: string;
  name: string;
  status: 'ATIVO' | 'INATIVO';
  created_at: string;
  updated_at: string;
}

let mockProductionSectors: ProductionSector[] = [
  { id: 'sec-1', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Impressão', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'sec-2', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Corte e Vinco', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'sec-3', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Colagem', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'sec-4', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Guilhotina', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'sec-5', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Manuseio', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'sec-6', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Expedição', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'sec-7', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Concluído', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'sec-8', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Estoque', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() }
];

let mockProductionMachines: ProductionMachine[] = [
  { id: 'mach-1', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Impressora Offset Heidel', sector: 'Impressão', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'mach-2', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Corte e Vinco Bobst', sector: 'Corte e Vinco', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'mach-3', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Guilhotina Rotalina A', sector: 'Corte e Vinco', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() }
];

let mockOrderItemSectorHistory: OrderItemSectorHistory[] = [
  {
    id: 'h-1',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_item_id: 'i00184c8-3e4b-4b14-87cf-45ef42d17i01',
    sector: 'Impressão',
    machine_id: 'mach-1',
    entered_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    exited_at: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
    created_at: new Date().toISOString()
  },
  {
    id: 'h-2',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_item_id: 'i00184c8-3e4b-4b14-87cf-45ef42d17i01',
    sector: 'Corte e Vinco',
    machine_id: 'mach-2',
    entered_at: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
    exited_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    created_at: new Date().toISOString()
  },
  {
    id: 'h-3',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_item_id: 'i00184c8-3e4b-4b14-87cf-45ef42d17i01',
    sector: 'Manuseio',
    machine_id: null,
    entered_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    exited_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    created_at: new Date().toISOString()
  },
  {
    id: 'h-4',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_item_id: 'i00184c8-3e4b-4b14-87cf-45ef42d17i01',
    sector: 'Expedição',
    machine_id: null,
    entered_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    exited_at: null,
    created_at: new Date().toISOString()
  },
  // Outro item do PV 1
  {
    id: 'h-5',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_item_id: 'i00184c8-3e4b-4b14-87cf-45ef42d17i02',
    sector: 'Impressão',
    machine_id: 'mach-1',
    entered_at: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
    exited_at: new Date(Date.now() - 3.5 * 24 * 60 * 60 * 1000).toISOString(),
    created_at: new Date().toISOString()
  },
  {
    id: 'h-6',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_item_id: 'i00184c8-3e4b-4b14-87cf-45ef42d17i02',
    sector: 'Corte e Vinco',
    machine_id: 'mach-3',
    entered_at: new Date(Date.now() - 3.5 * 24 * 60 * 60 * 1000).toISOString(),
    exited_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    created_at: new Date().toISOString()
  },
  {
    id: 'h-7',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_item_id: 'i00184c8-3e4b-4b14-87cf-45ef42d17i02',
    sector: 'Colagem',
    machine_id: null,
    entered_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    exited_at: null,
    created_at: new Date().toISOString()
  },
  // Item 3 (PV-1002/1)
  {
    id: 'h-8',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_item_id: 'i00284c8-3e4b-4b14-87cf-45ef42d17i03',
    sector: 'Impressão',
    machine_id: 'mach-1',
    entered_at: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString(),
    exited_at: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
    created_at: new Date().toISOString()
  },
  {
    id: 'h-9',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_item_id: 'i00284c8-3e4b-4b14-87cf-45ef42d17i03',
    sector: 'Atrasado',
    machine_id: null,
    entered_at: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
    exited_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    created_at: new Date().toISOString()
  },
  {
    id: 'h-10',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    order_item_id: 'i00284c8-3e4b-4b14-87cf-45ef42d17i03',
    sector: 'Colagem',
    machine_id: null,
    entered_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    exited_at: null,
    created_at: new Date().toISOString()
  }
];

export async function getProductionMachines(tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    const list = mockProductionMachines.filter(m => m.tenant_id === tenantId);
    return { data: list, error: null };
  }

  // Se executado no cliente, chama a rota de API do servidor para pular RLS de máquinas
  if (typeof window !== 'undefined') {
    try {
      const response = await fetch('/api/config/machines');
      if (!response.ok) {
        throw new Error('Falha ao obter máquinas via API');
      }
      const json = await response.json();
      return { data: json.data, error: null };
    } catch (err: any) {
      return { data: null, error: err };
    }
  }

  const { data, error } = await getDbClient()
    .from('production_machines')
    .select('*')
    .eq('tenant_id', tenantId)
    .order('name', { ascending: true });
  return { data, error };
}

export async function createProductionMachine(machine: Omit<ProductionMachine, 'id' | 'created_at' | 'updated_at'>) {
  const tenantId = machine.tenant_id || 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0';
  if (isMockMode) {
    const newMac: ProductionMachine = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      ...machine,
      tenant_id: tenantId,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    mockProductionMachines.push(newMac);
    return { data: newMac, error: null };
  }

  if (typeof window !== 'undefined') {
    try {
      const response = await fetch('/api/config/machines', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...machine, tenant_id: tenantId })
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || 'Falha ao criar máquina');
      return { data: json.data, error: null };
    } catch (err: any) {
      return { data: null, error: err };
    }
  }

  const { data, error } = await getDbClient()
    .from('production_machines')
    .insert([{ ...machine, tenant_id: tenantId }])
    .select()
    .single();
  return { data, error };
}

export async function updateProductionMachine(id: string, updates: Partial<ProductionMachine>) {
  if (isMockMode) {
    mockProductionMachines = mockProductionMachines.map(m => m.id === id ? { ...m, ...updates, updated_at: new Date().toISOString() } : m);
    const updated = mockProductionMachines.find(m => m.id === id);
    return { data: updated, error: null };
  }

  if (typeof window !== 'undefined') {
    try {
      const response = await fetch('/api/config/machines', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, ...updates })
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || 'Falha ao atualizar máquina');
      return { data: json.data, error: null };
    } catch (err: any) {
      return { data: null, error: err };
    }
  }

  const { data, error } = await getDbClient()
    .from('production_machines')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();
  return { data, error };
}

export async function deleteProductionMachine(id: string) {
  if (isMockMode) {
    mockProductionMachines = mockProductionMachines.filter(m => m.id !== id);
    return { data: true, error: null };
  }

  if (typeof window !== 'undefined') {
    try {
      const response = await fetch(`/api/config/machines?id=${encodeURIComponent(id)}`, {
        method: 'DELETE'
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || 'Falha ao excluir máquina');
      return { data: true, error: null };
    } catch (err: any) {
      return { data: false, error: err };
    }
  }

  const { error } = await getDbClient()
    .from('production_machines')
    .delete()
    .eq('id', id);
  return { data: !error, error };
}

export async function getProductionSectors(tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    const list = mockProductionSectors.filter(s => s.tenant_id === tenantId);
    return { data: list, error: null };
  }

  // Se executado no cliente, chama a rota de API do servidor para pular RLS de setores
  if (typeof window !== 'undefined') {
    try {
      const response = await fetch('/api/config/sectors');
      if (!response.ok) {
        throw new Error('Falha ao obter setores via API');
      }
      const json = await response.json();
      return { data: json.data, error: null };
    } catch (err: any) {
      return { data: null, error: err };
    }
  }

  const { data, error } = await getDbClient()
    .from('production_sectors')
    .select('*')
    .eq('tenant_id', tenantId)
    .order('name', { ascending: true });
  return { data, error };
}

export async function createProductionSector(sector: Omit<ProductionSector, 'id' | 'created_at' | 'updated_at'>) {
  const tenantId = sector.tenant_id || 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0';
  if (isMockMode) {
    const newSec: ProductionSector = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      ...sector,
      tenant_id: tenantId,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    mockProductionSectors.push(newSec);
    return { data: newSec, error: null };
  }

  if (typeof window !== 'undefined') {
    try {
      const response = await fetch('/api/config/sectors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...sector, tenant_id: tenantId })
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || 'Falha ao criar setor');
      return { data: json.data, error: null };
    } catch (err: any) {
      return { data: null, error: err };
    }
  }

  const { data, error } = await getDbClient()
    .from('production_sectors')
    .insert([{ ...sector, tenant_id: tenantId }])
    .select()
    .maybeSingle();
  return { data, error };
}

export async function updateProductionSector(id: string, updates: Partial<ProductionSector>) {
  if (isMockMode) {
    mockProductionSectors = mockProductionSectors.map(s => s.id === id ? { ...s, ...updates, updated_at: new Date().toISOString() } : s);
    const updated = mockProductionSectors.find(s => s.id === id);
    return { data: updated, error: null };
  }

  if (typeof window !== 'undefined') {
    try {
      const response = await fetch('/api/config/sectors', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, ...updates })
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || 'Falha ao atualizar setor');
      return { data: json.data, error: null };
    } catch (err: any) {
      return { data: null, error: err };
    }
  }

  const { data, error } = await getDbClient()
    .from('production_sectors')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .maybeSingle();
  return { data, error };
}

export async function deleteProductionSector(id: string) {
  if (isMockMode) {
    mockProductionSectors = mockProductionSectors.filter(s => s.id !== id);
    return { data: true, error: null };
  }

  if (typeof window !== 'undefined') {
    try {
      const response = await fetch(`/api/config/sectors?id=${encodeURIComponent(id)}`, {
        method: 'DELETE'
      });
      const json = await response.json();
      if (!response.ok) throw new Error(json.error || 'Falha ao excluir setor');
      return { data: true, error: null };
    } catch (err: any) {
      return { data: false, error: err };
    }
  }

  const { error } = await getDbClient()
    .from('production_sectors')
    .delete()
    .eq('id', id);
  return { data: !error, error };
}

export async function getOrderItemSectorHistory(orderItemId: string, tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    const list = mockOrderItemSectorHistory
      .filter(h => h.order_item_id === orderItemId && h.tenant_id === tenantId)
      .map(h => ({
        ...h,
        machine: mockProductionMachines.find(m => m.id === h.machine_id) || null
      }));
    return { data: list, error: null };
  }
  const { data, error } = await getDbClient()
    .from('order_item_sector_history')
    .select('*, machine:production_machines(*), operator:profiles(*)')
    .eq('order_item_id', orderItemId)
    .eq('tenant_id', tenantId)
    .order('entered_at', { ascending: true });
  return { data, error };
}

export async function logSectorTransition(
  orderItemId: string,
  sector: string,
  machineId: string | null,
  tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
  operatorId?: string | null
) {
  if (isMockMode) {
    // 1. Fechar transição aberta anterior
    mockOrderItemSectorHistory = mockOrderItemSectorHistory.map(h => {
      if (h.order_item_id === orderItemId && h.exited_at === null) {
        return { ...h, exited_at: new Date().toISOString() };
      }
      return h;
    });

    // 2. Inserir nova transição
    const newLog: OrderItemSectorHistory = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      tenant_id: tenantId,
      order_item_id: orderItemId,
      sector,
      machine_id: machineId,
      entered_at: new Date().toISOString(),
      exited_at: null,
      created_at: new Date().toISOString(),
      operator_id: operatorId || null
    } as any;
    mockOrderItemSectorHistory.push(newLog);
    return { data: newLog, error: null };
  }

  const db = getDbClient();
  
  // 1. Fechar transição aberta anterior
  await db
    .from('order_item_sector_history')
    .update({ exited_at: new Date().toISOString() })
    .eq('order_item_id', orderItemId)
    .is('exited_at', null);

  // 2. Inserir nova transição
  const { data, error } = await db
    .from('order_item_sector_history')
    .insert([{
      tenant_id: tenantId,
      order_item_id: orderItemId,
      sector,
      machine_id: machineId,
      entered_at: new Date().toISOString(),
      operator_id: operatorId || null
    }])
    .select()
    .single();

  return { data, error };
}

// --- OPERAÇÕES: OPERADORES DE PRODUÇÃO ---

export interface ProductionOperator {
  id: string;
  tenant_id: string;
  name: string;
  pin_hash: string;
  password_hash: string;
  status: 'ATIVO' | 'INATIVO';
  created_at: string;
  updated_at: string;
}

let mockOperators: ProductionOperator[] = [
  {
    id: 'op-1',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    name: 'Operador Teste Alfa',
    pin_hash: '$2a$10$sD8sL5fApe2V6eJb.sLHeOlyb.cQ9Nn9jD6lBskH0bJ/sSg0cKeve', // bcrypt para '1234'
    password_hash: '$2a$10$sD8sL5fApe2V6eJb.sLHeOlyb.cQ9Nn9jD6lBskH0bJ/sSg0cKeve', // bcrypt para '123456'
    status: 'ATIVO',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

export async function getOperators(tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    return { data: mockOperators.filter(o => o.tenant_id === tenantId), error: null };
  }
  const { data, error } = await getDbClient()
    .from('profiles')
    .select('id, full_name, email, status, created_at')
    .eq('tenant_id', tenantId)
    .eq('role', 'Produção')
    .order('full_name', { ascending: true });

  const mappedData = data ? data.map(p => ({
    id: p.id,
    name: p.full_name,
    email: p.email,
    status: p.status || 'ATIVO',
    created_at: p.created_at
  })) : null;

  return { data: mappedData, error };
}

export async function getActiveOperators(tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    return { data: mockOperators.filter(o => o.tenant_id === tenantId && o.status === 'ATIVO'), error: null };
  }
  const { data, error } = await getDbClient()
    .from('profiles')
    .select('id, full_name, status')
    .eq('tenant_id', tenantId)
    .eq('role', 'Produção')
    .eq('status', 'ATIVO')
    .order('full_name', { ascending: true });

  const mappedData = data ? data.map(p => ({
    id: p.id,
    name: p.full_name,
    status: p.status || 'ATIVO'
  })) : null;

  return { data: mappedData, error };
}

export async function createOperator(operator: any) {
  const tenantId = operator.tenant_id || 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0';
  if (isMockMode) {
    const newOp = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      ...operator,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    mockOperators.push(newOp);
    return { data: newOp, error: null };
  }
  const { data, error } = await getDbClient()
    .from('profiles')
    .insert([{ 
      full_name: operator.name, 
      email: operator.email,
      role: 'Produção', 
      tenant_id: tenantId, 
      status: operator.status || 'ATIVO',
      pin: operator.pin
    }])
    .select()
    .single();
  return { data, error };
}

export async function updateOperator(id: string, updates: any) {
  if (isMockMode) {
    mockOperators = mockOperators.map(o => o.id === id ? { ...o, ...updates, updated_at: new Date().toISOString() } : o);
    const updated = mockOperators.find(o => o.id === id);
    return { data: updated, error: null };
  }
  
  const dbPayload: any = {};
  if (updates.name !== undefined) dbPayload.full_name = updates.name;
  if (updates.status !== undefined) dbPayload.status = updates.status;
  if (updates.pin !== undefined) dbPayload.pin = updates.pin;

  const { data, error } = await getDbClient()
    .from('profiles')
    .update(dbPayload)
    .eq('id', id)
    .select()
    .single();
  return { data, error };
}

export async function updateOperatorStatus(id: string, status: 'ATIVO' | 'INATIVO') {
  return updateOperator(id, { status });
}

// --- OPERAÇÕES: EQUIPES DE MANUSEIO ---

export interface HandlingTeam {
  id: string;
  tenant_id: string;
  name: string;
  status: 'ATIVO' | 'INATIVO';
  created_at: string;
  updated_at: string;
}

let mockHandlingTeams: HandlingTeam[] = [
  { id: 'team-1', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Equipe João', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'team-2', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Equipe Zé', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'team-3', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Equipe Maria', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() }
];

export async function getHandlingTeams(tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    const list = mockHandlingTeams.filter(t => t.tenant_id === tenantId);
    return { data: list.length > 0 ? list : mockHandlingTeams, error: null };
  }
  try {
    const { data, error } = await getDbClient()
      .from('handling_teams')
      .select('*')
      .order('name', { ascending: true });
    if (data && data.length > 0) {
      return { data, error: null };
    }
  } catch (e) {}
  return { data: mockHandlingTeams, error: null };
}

export async function createHandlingTeam(team: Omit<HandlingTeam, 'id' | 'created_at' | 'updated_at'>) {
  const tenantId = team.tenant_id || 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0';
  if (isMockMode) {
    const newTeam: HandlingTeam = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      ...team,
      tenant_id: tenantId,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    mockHandlingTeams.push(newTeam);
    return { data: newTeam, error: null };
  }
  const { data, error } = await getDbClient()
    .from('handling_teams')
    .insert([{ ...team, tenant_id: tenantId }])
    .select()
    .single();
  return { data, error };
}

export async function updateHandlingTeam(id: string, updates: Partial<HandlingTeam>) {
  if (isMockMode) {
    mockHandlingTeams = mockHandlingTeams.map(t => t.id === id ? { ...t, ...updates, updated_at: new Date().toISOString() } : t);
    const updated = mockHandlingTeams.find(t => t.id === id);
    return { data: updated, error: null };
  }
  const { data, error } = await getDbClient()
    .from('handling_teams')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();
  return { data, error };
}

export async function deleteHandlingTeam(id: string) {
  if (isMockMode) {
    mockHandlingTeams = mockHandlingTeams.filter(t => t.id !== id);
    return { data: true, error: null };
  }
  const { error } = await getDbClient()
    .from('handling_teams')
    .delete()
    .eq('id', id);
  return { data: !error, error };
}

// ─────────────────────────────────────────────────────────────────
// OPERAÇÕES: DIVISÃO DE EQUIPES DE MANUSEIO POR ITEM
// ─────────────────────────────────────────────────────────────────

export interface OrderItemHandlingTeam {
  id: string;
  tenant_id: string;
  order_item_id: string;
  handling_team_id: string;
  quantity: number;
  departure_date?: string | null;
  return_quantity?: number | null;
  return_date?: string | null;
  handling_code?: string | null;
  is_completed?: boolean;
  completed_at?: string | null;
  team?: HandlingTeam;
  created_at?: string;
  updated_at?: string;
}

let mockOrderItemHandlingTeams: OrderItemHandlingTeam[] = [];
const HANDLING_CACHE_KEY = 'samppel_handling_teams_v2';

function loadHandlingCache(): OrderItemHandlingTeam[] {
  if (typeof window === 'undefined') return mockOrderItemHandlingTeams;
  try {
    const raw = localStorage.getItem(HANDLING_CACHE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        mockOrderItemHandlingTeams = parsed;
      }
    }
  } catch (e) {
    console.warn('Erro ao carregar cache de equipes de manuseio:', e);
  }
  return mockOrderItemHandlingTeams;
}

function saveHandlingCache(list: OrderItemHandlingTeam[]) {
  mockOrderItemHandlingTeams = list;
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(HANDLING_CACHE_KEY, JSON.stringify(list));
    } catch (e) {
      console.warn('Erro ao salvar cache de equipes de manuseio:', e);
    }
  }
}

export async function getOrderItemHandlingTeams(orderItemId: string) {
  const currentCache = loadHandlingCache();

  if (isMockMode) {
    const list = currentCache.filter(t => t.order_item_id === orderItemId);
    return { data: list, error: null };
  }

  try {
    const { data, error } = await getDbClient()
      .from('order_item_handling_teams')
      .select('*, team:handling_teams(*)')
      .eq('order_item_id', orderItemId);

    if (data && data.length > 0) {
      const updated = [
        ...currentCache.filter(t => t.order_item_id !== orderItemId),
        ...data
      ];
      saveHandlingCache(updated);
      return { data, error: null };
    }
  } catch (err) {
    console.warn('Falha na consulta remota de equipes de manuseio:', err);
  }

  const mockList = currentCache.filter(t => t.order_item_id === orderItemId);
  return { data: mockList, error: null };
}

export async function getOrderItemHandlingTeamsBulk(orderItemIds: string[]) {
  const currentCache = loadHandlingCache();

  if (!orderItemIds || orderItemIds.length === 0) {
    return { data: currentCache, error: null };
  }

  if (isMockMode) {
    const list = currentCache.filter(t => orderItemIds.includes(t.order_item_id));
    return { data: list, error: null };
  }

  try {
    const { data, error } = await getDbClient()
      .from('order_item_handling_teams')
      .select('*, team:handling_teams(*)')
      .in('order_item_id', orderItemIds);

    if (data && data.length > 0) {
      const cacheMap = new Map(currentCache.map(c => [c.id, c]));
      data.forEach(d => cacheMap.set(d.id, d));
      const updatedList = Array.from(cacheMap.values());
      saveHandlingCache(updatedList);
      return { data, error: null };
    }
  } catch (err) {
    console.warn('Falha na consulta remota bulk de equipes de manuseio:', err);
  }

  const mockList = currentCache.filter(t => orderItemIds.includes(t.order_item_id));
  return { data: mockList, error: null };
}

export async function saveOrderItemHandlingTeams(
  orderItemId: string,
  teams: {
    handling_team_id: string;
    quantity: number;
    departure_date?: string | null;
    return_quantity?: number | null;
    return_date?: string | null;
    handling_code?: string | null;
    is_completed?: boolean;
    completed_at?: string | null;
  }[],
  tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0'
) {
  const currentCache = loadHandlingCache();

  // Filtra itens com equipe válida e quantidade > 0
  const validTeams = teams.filter(t => t.handling_team_id && Number(t.quantity) > 0);

  // Cria lista atualizada de alocações para o item
  const newAllocations: OrderItemHandlingTeam[] = validTeams.map((t, idx) => ({
    id: (t as any).id || `h-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 6)}`,
    tenant_id: tenantId,
    order_item_id: orderItemId,
    handling_team_id: t.handling_team_id,
    quantity: Number(t.quantity),
    departure_date: t.departure_date || null,
    return_quantity: Number(t.return_quantity || 0),
    return_date: t.return_date || t.completed_at || null,
    handling_code: t.handling_code || null,
    is_completed: t.is_completed || false,
    completed_at: t.completed_at || t.return_date || null
  }));

  // Atualiza cache em localStorage imediatamente
  const updatedCache = [
    ...currentCache.filter(t => t.order_item_id !== orderItemId),
    ...newAllocations
  ];
  saveHandlingCache(updatedCache);

  if (isMockMode || validTeams.length === 0) {
    return { data: newAllocations, error: null };
  }

  // Persiste no Supabase
  try {
    await getDbClient()
      .from('order_item_handling_teams')
      .delete()
      .eq('order_item_id', orderItemId);

    const payload = newAllocations.map(t => ({
      tenant_id: tenantId,
      order_item_id: orderItemId,
      handling_team_id: t.handling_team_id,
      quantity: Number(t.quantity),
      departure_date: t.departure_date ? t.departure_date : null,
      return_quantity: t.return_quantity ? Number(t.return_quantity) : 0,
      return_date: t.return_date ? t.return_date : (t.completed_at ? t.completed_at : null),
      handling_code: t.handling_code ? t.handling_code : null,
      is_completed: t.is_completed || false,
      completed_at: t.completed_at ? t.completed_at : (t.return_date ? t.return_date : null)
    }));

    let { data, error } = await getDbClient()
      .from('order_item_handling_teams')
      .insert(payload)
      .select('*, team:handling_teams(*)');

    if (error || !data || data.length < validTeams.length) {
      console.warn('Inserção no Supabase com alerta/restrição. Tentando inserção individual:', error?.message);
      const individualSaved: any[] = [];
      for (const p of payload) {
        const res = await getDbClient()
          .from('order_item_handling_teams')
          .insert([p])
          .select('*, team:handling_teams(*)');
        if (res.data && res.data.length > 0) {
          individualSaved.push(...res.data);
        }
      }
      if (individualSaved.length > 0) {
        data = individualSaved;
      }
    }

    if (data && data.length > 0) {
      const finalCache = [
        ...loadHandlingCache().filter(t => t.order_item_id !== orderItemId),
        ...data
      ];
      saveHandlingCache(finalCache);
      return { data, error: null };
    }
  } catch (dbErr) {
    console.warn('Erro ao salvar no banco remoto Supabase, mantendo no cache local:', dbErr);
  }

  return { data: newAllocations, error: null };
}

// ─────────────────────────────────────────────────────────────────
// OPERAÇÕES: LOCALIZAÇÕES FÍSICAS NA FÁBRICA
// ─────────────────────────────────────────────────────────────────

export interface FactoryLocation {
  id: string;
  tenant_id: string;
  name: string;
  status: 'ATIVO' | 'INATIVO';
  created_at: string;
  updated_at: string;
}

let mockFactoryLocations: FactoryLocation[] = [
  { id: 'loc-1', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Salão', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'loc-2', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Pátio', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'loc-3', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Máquina Flexo 1', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'loc-4', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Máquina Coladeira 2', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'loc-5', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Prateleira A1', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'loc-6', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Depósito de Materiais', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() }
];

export async function getFactoryLocations(tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    const list = mockFactoryLocations.filter(l => l.tenant_id === tenantId);
    return { data: list, error: null };
  }
  const { data, error } = await getDbClient()
    .from('factory_locations')
    .select('*')
    .eq('tenant_id', tenantId)
    .order('name', { ascending: true });
  return { data, error };
}

export async function createFactoryLocation(loc: Omit<FactoryLocation, 'id' | 'created_at' | 'updated_at'>) {
  const tenantId = loc.tenant_id || 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0';
  if (isMockMode) {
    const newLoc: FactoryLocation = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      ...loc,
      tenant_id: tenantId,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    mockFactoryLocations.push(newLoc);
    return { data: newLoc, error: null };
  }
  const { data, error } = await getDbClient()
    .from('factory_locations')
    .insert([{ ...loc, tenant_id: tenantId }])
    .select()
    .single();
  return { data, error };
}

export async function updateFactoryLocation(id: string, updates: Partial<FactoryLocation>) {
  if (isMockMode) {
    mockFactoryLocations = mockFactoryLocations.map(l => l.id === id ? { ...l, ...updates, updated_at: new Date().toISOString() } : l);
    const updated = mockFactoryLocations.find(l => l.id === id);
    return { data: updated, error: null };
  }
  const { data, error } = await getDbClient()
    .from('factory_locations')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();
  return { data, error };
}

export async function deleteFactoryLocation(id: string) {
  if (isMockMode) {
    mockFactoryLocations = mockFactoryLocations.filter(l => l.id !== id);
    return { data: true, error: null };
  }
  const { error } = await getDbClient()
    .from('factory_locations')
    .delete()
    .eq('id', id);
  return { data: !error, error };
}

// ─────────────────────────────────────────────────────────────────
// OPERAÇÕES: TIPOS DE MATERIAL DE EMBALAGEM
// ─────────────────────────────────────────────────────────────────

export interface PackagingMaterialType {
  id: string;
  tenant_id: string;
  name: string;
  code: string | null;
  category: 'CAIXA' | 'FUNDO' | 'DIVISORIA' | 'SACO' | 'OUTRO';
  status: 'ATIVO' | 'INATIVO';
  created_at: string;
  updated_at: string;
}

function shouldFallbackToMock(error: any): boolean {
  if (!error) return false;
  return (
    error.code === 'PGRST205' ||
    error.code === '42P01' ||
    String(error.message).includes('schema cache') ||
    String(error.message).includes('does not exist')
  );
}

let mockPackagingMaterialTypes: PackagingMaterialType[] = [
  { id: 'pmt-1', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Caixa de Papelão Corrugado', code: 'CX-001', category: 'CAIXA', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'pmt-2', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Fundo Reforçado Kraft', code: 'FD-001', category: 'FUNDO', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'pmt-3', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Divisória Interna', code: 'DV-001', category: 'DIVISORIA', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
];

export async function getPackagingMaterialTypes(tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    return { data: mockPackagingMaterialTypes.filter(t => t.tenant_id === tenantId), error: null };
  }
  const { data, error } = await getDbClient()
    .from('packaging_material_types')
    .select('*')
    .eq('tenant_id', tenantId)
    .order('name', { ascending: true });

  if (error && shouldFallbackToMock(error)) {
    return { data: mockPackagingMaterialTypes.filter(t => t.tenant_id === tenantId), error: null };
  }
  return { data, error };
}

export async function createPackagingMaterialType(item: Omit<PackagingMaterialType, 'id' | 'created_at' | 'updated_at'>) {
  const tenantId = item.tenant_id || 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0';
  if (isMockMode) {
    const newItem: PackagingMaterialType = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      ...item,
      tenant_id: tenantId,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    mockPackagingMaterialTypes.push(newItem);
    return { data: newItem, error: null };
  }
  const { data, error } = await getDbClient()
    .from('packaging_material_types')
    .insert([{ ...item, tenant_id: tenantId }])
    .select()
    .single();

  if (error && shouldFallbackToMock(error)) {
    const newItem: PackagingMaterialType = {
      id: Math.random().toString(36).substring(2),
      ...item,
      tenant_id: tenantId,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    mockPackagingMaterialTypes.push(newItem);
    return { data: newItem, error: null };
  }
  return { data, error };
}

export async function updatePackagingMaterialType(id: string, updates: Partial<PackagingMaterialType>) {
  if (isMockMode) {
    mockPackagingMaterialTypes = mockPackagingMaterialTypes.map(t =>
      t.id === id ? { ...t, ...updates, updated_at: new Date().toISOString() } : t
    );
    return { data: mockPackagingMaterialTypes.find(t => t.id === id), error: null };
  }
  const { data, error } = await getDbClient()
    .from('packaging_material_types')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();

  if (error && shouldFallbackToMock(error)) {
    mockPackagingMaterialTypes = mockPackagingMaterialTypes.map(t =>
      t.id === id ? { ...t, ...updates, updated_at: new Date().toISOString() } : t
    );
    return { data: mockPackagingMaterialTypes.find(t => t.id === id), error: null };
  }
  return { data, error };
}

export async function deletePackagingMaterialType(id: string) {
  if (isMockMode) {
    mockPackagingMaterialTypes = mockPackagingMaterialTypes.filter(t => t.id !== id);
    return { data: true, error: null };
  }
  const { error } = await getDbClient().from('packaging_material_types').delete().eq('id', id);
  if (error && shouldFallbackToMock(error)) {
    mockPackagingMaterialTypes = mockPackagingMaterialTypes.filter(t => t.id !== id);
    return { data: true, error: null };
  }
  return { data: !error, error };
}

// ─────────────────────────────────────────────────────────────────
// OPERAÇÕES: VOLUMES DE EMBALAGEM POR ITEM DE PEDIDO
// ─────────────────────────────────────────────────────────────────

export interface OrderItemPackaging {
  id: string;
  tenant_id: string;
  order_item_id: string;
  volume_index: number;
  units_per_box: number;
  box_count: number;
  weight_kg: number | null;
  length_cm: number | null;
  width_cm: number | null;
  height_cm: number | null;
  packaging_material_type_id: string | null;
  associated_order_item_id: string | null;
  notes: string | null;
  registered_by: string | null;
  created_at: string;
  updated_at: string;
  // joined
  material_type?: PackagingMaterialType | null;
}

let mockOrderItemPackaging: OrderItemPackaging[] = [];

export async function getOrderItemPackaging(orderItemId: string) {
  if (isMockMode) {
    const records = mockOrderItemPackaging.filter(p => p.order_item_id === orderItemId);
    // Join mock material type
    records.forEach(r => {
      r.material_type = mockPackagingMaterialTypes.find(t => t.id === r.packaging_material_type_id) || null;
    });
    return { data: records, error: null };
  }
  const { data, error } = await getDbClient()
    .from('order_item_packaging')
    .select('*, material_type:packaging_material_types(*)')
    .eq('order_item_id', orderItemId)
    .order('volume_index', { ascending: true });

  if (error && shouldFallbackToMock(error)) {
    const records = mockOrderItemPackaging.filter(p => p.order_item_id === orderItemId);
    records.forEach(r => {
      r.material_type = mockPackagingMaterialTypes.find(t => t.id === r.packaging_material_type_id) || null;
    });
    return { data: records, error: null };
  }
  return { data, error };
}

export async function saveOrderItemPackagingVolumes(
  orderItemId: string,
  tenantId: string,
  volumes: Omit<OrderItemPackaging, 'id' | 'created_at' | 'updated_at' | 'material_type'>[],
  registeredBy?: string
) {
  if (isMockMode) {
    // Remove existing records for this item
    mockOrderItemPackaging = mockOrderItemPackaging.filter(p => p.order_item_id !== orderItemId);
    const now = new Date().toISOString();
    const newRecords: OrderItemPackaging[] = volumes.map((v, i) => ({
      ...v,
      id: Math.random().toString(36).substring(2),
      order_item_id: orderItemId,
      tenant_id: tenantId,
      volume_index: i + 1,
      registered_by: registeredBy || null,
      created_at: now,
      updated_at: now
    }));
    mockOrderItemPackaging.push(...newRecords);
    return { data: newRecords, error: null };
  }

  const db = getDbClient();
  try {
    // Delete existing and re-insert
    await db.from('order_item_packaging').delete().eq('order_item_id', orderItemId);
    const now = new Date().toISOString();
    const records = volumes.map((v, i) => ({
      ...v,
      order_item_id: orderItemId,
      tenant_id: tenantId,
      volume_index: i + 1,
      registered_by: registeredBy || null,
      updated_at: now
    }));

    if (records.length === 0) return { data: [], error: null };

    const { data, error } = await db
      .from('order_item_packaging')
      .insert(records)
      .select();

    if (error && shouldFallbackToMock(error)) {
      throw error; // Let try-catch block handle fallback
    }
    return { data, error };
  } catch (err: any) {
    if (shouldFallbackToMock(err)) {
      mockOrderItemPackaging = mockOrderItemPackaging.filter(p => p.order_item_id !== orderItemId);
      const now = new Date().toISOString();
      const newRecords: OrderItemPackaging[] = volumes.map((v, i) => ({
        ...v,
        id: Math.random().toString(36).substring(2),
        order_item_id: orderItemId,
        tenant_id: tenantId,
        volume_index: i + 1,
        registered_by: registeredBy || null,
        created_at: now,
        updated_at: now
      }));
      mockOrderItemPackaging.push(...newRecords);
      return { data: newRecords, error: null };
    }
    throw err;
  }
}

export async function hasPackagingData(orderItemId: string): Promise<boolean> {
  if (isMockMode) {
    return mockOrderItemPackaging.some(p => p.order_item_id === orderItemId);
  }
  const { count, error } = await getDbClient()
    .from('order_item_packaging')
    .select('id', { count: 'exact', head: true })
    .eq('order_item_id', orderItemId);

  if (error && shouldFallbackToMock(error)) {
    return mockOrderItemPackaging.some(p => p.order_item_id === orderItemId);
  }
  return (count || 0) > 0;
}

// ─────────────────────────────────────────────────────────────────
// OPERAÇÕES: CONFIGURAÇÕES DE EMBALAGEM (CONVENÇÕES)
// ─────────────────────────────────────────────────────────────────

export interface PackagingSettings {
  id: string;
  tenant_id: string;
  keywords: string;
  association_rule: 'FIRST_ITEM' | 'LARGEST_QUANTITY' | 'MANUAL';
  created_at: string;
  updated_at: string;
}

let mockPackagingSettings: PackagingSettings[] = [
  {
    id: 'ps-1',
    tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
    keywords: 'caixa,fundo,divisoria,saco,embalagem,pacote',
    association_rule: 'FIRST_ITEM',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

export async function getPackagingSettings(tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    const config = mockPackagingSettings.find(s => s.tenant_id === tenantId) || {
      id: 'ps-temp',
      tenant_id: tenantId,
      keywords: 'caixa,fundo,divisoria,saco,embalagem,pacote',
      association_rule: 'FIRST_ITEM' as const,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    return { data: config, error: null };
  }

  const { data, error } = await getDbClient()
    .from('packaging_settings')
    .select('*')
    .eq('tenant_id', tenantId)
    .maybeSingle();

  if (error && shouldFallbackToMock(error)) {
    const config = mockPackagingSettings.find(s => s.tenant_id === tenantId) || {
      id: 'ps-temp',
      tenant_id: tenantId,
      keywords: 'caixa,fundo,divisoria,saco,embalagem,pacote',
      association_rule: 'FIRST_ITEM' as const,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    return { data: config, error: null };
  }

  // Se nao encontrar registro, retorna um padrao inicial sem erro
  if (!data && !error) {
    const defaultSettings = {
      id: 'ps-default',
      tenant_id: tenantId,
      keywords: 'caixa,fundo,divisoria,saco,embalagem,pacote',
      association_rule: 'FIRST_ITEM' as const,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    return { data: defaultSettings, error: null };
  }

  return { data, error };
}

export async function savePackagingSettings(item: Omit<PackagingSettings, 'id' | 'created_at' | 'updated_at'>) {
  const tenantId = item.tenant_id || 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0';
  if (isMockMode) {
    let config = mockPackagingSettings.find(s => s.tenant_id === tenantId);
    if (config) {
      config.keywords = item.keywords;
      config.association_rule = item.association_rule;
      config.updated_at = new Date().toISOString();
    } else {
      config = {
        id: Math.random().toString(36).substring(2),
        tenant_id: tenantId,
        keywords: item.keywords,
        association_rule: item.association_rule,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      mockPackagingSettings.push(config);
    }
    return { data: config, error: null };
  }

  const { data, error } = await getDbClient()
    .from('packaging_settings')
    .upsert({
      tenant_id: tenantId,
      keywords: item.keywords,
      association_rule: item.association_rule,
      updated_at: new Date().toISOString()
    }, { onConflict: 'tenant_id' })
    .select()
    .single();

  if (error && shouldFallbackToMock(error)) {
    let config = mockPackagingSettings.find(s => s.tenant_id === tenantId);
    if (config) {
      config.keywords = item.keywords;
      config.association_rule = item.association_rule;
      config.updated_at = new Date().toISOString();
    } else {
      config = {
        id: Math.random().toString(36).substring(2),
        tenant_id: tenantId,
        keywords: item.keywords,
        association_rule: item.association_rule,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      mockPackagingSettings.push(config);
    }
    return { data: config, error: null };
  }
  return { data, error };
}

// ─────────────────────────────────────────────────────────────────
// RELATÓRIOS E AUDITORIA DE TRANSIÇÕES DE SETOR / MÁQUINAS
// ─────────────────────────────────────────────────────────────────

export async function getSectorTransitionReport(
  tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
  filters: {
    startDate?: string;
    endDate?: string;
    customerId?: string;
    productId?: string;
    machineId?: string;
  } = {}
) {
  let historyData: any[] = [];
  
  if (isMockMode) {
    historyData = [...mockOrderItemSectorHistory].filter(h => h.tenant_id === tenantId);
  } else {
    const { data, error } = await getDbClient()
      .from('order_item_sector_history')
      .select('*, order_item:order_items(*, order:orders(*, customer:customers(*), product:products(*)), machine:production_machines(*))')
      .eq('tenant_id', tenantId);

    if (error && shouldFallbackToMock(error)) {
      historyData = [...mockOrderItemSectorHistory].filter(h => h.tenant_id === tenantId);
    } else {
      historyData = data || [];
    }
  }

  // Preencher dados em modo simulação (ou fallback)
  if (isMockMode || historyData.length === 0 || !historyData[0]?.order_item) {
    historyData = historyData.map(h => {
      const orderItem = mockOrderItems.find(oi => oi.id === h.order_item_id) || null;
      let order: any = null;
      let customer: any = null;
      let product: any = null;
      if (orderItem) {
        order = mockOrders.find(o => o.id === orderItem.order_id) || null;
        if (order) {
          customer = mockCustomers.find(c => c.id === order.customer_id) || null;
          product = mockProducts.find(p => p.id === order.product_id) || null;
        }
      }
      const machine = mockProductionMachines.find(m => m.id === h.machine_id) || null;

      return {
        ...h,
        machine,
        order_item: orderItem ? {
          ...orderItem,
          order: order ? {
            ...order,
            customer,
            product
          } : null
        } : null
      };
    });
  }

  // Aplicar filtros de pesquisa
  let filtered = historyData;

  if (filters.startDate) {
    const start = new Date(filters.startDate).getTime();
    filtered = filtered.filter(h => new Date(h.entered_at).getTime() >= start);
  }
  if (filters.endDate) {
    const end = new Date(filters.endDate + 'T23:59:59').getTime();
    filtered = filtered.filter(h => new Date(h.entered_at).getTime() <= end);
  }
  if (filters.customerId) {
    filtered = filtered.filter(h => h.order_item?.order?.customer_id === filters.customerId);
  }
  if (filters.productId) {
    filtered = filtered.filter(h => h.order_item?.product_id === filters.productId || h.order_item?.order?.product_id === filters.productId);
  }
  if (filters.machineId) {
    filtered = filtered.filter(h => h.machine_id === filters.machineId);
  }

  // 1. Calcular tempo médio por etapa/setor
  const sectorDurations: Record<string, number[]> = {};
  filtered.forEach(h => {
    const start = new Date(h.entered_at).getTime();
    const end = h.exited_at ? new Date(h.exited_at).getTime() : Date.now();
    const duration = end - start;

    if (!sectorDurations[h.sector]) {
      sectorDurations[h.sector] = [];
    }
    sectorDurations[h.sector].push(duration);
  });

  const averageTimes = Object.keys(sectorDurations).map(sector => {
    const arr = sectorDurations[sector];
    const total = arr.reduce((sum, val) => sum + val, 0);
    const avgMs = arr.length ? total / arr.length : 0;
    const avgHours = Number((avgMs / (1000 * 60 * 60)).toFixed(2));
    return {
      sector,
      count: arr.length,
      averageHours: avgHours,
      averageDays: Number((avgHours / 24).toFixed(2))
    };
  });

  // 2. Identificar os cards que mais tempo demoraram (stays) por setor ou máquina
  const staysByItem: Record<string, { item: any; totalDuration: number; sector: string; machineName: string }> = {};
  filtered.forEach(h => {
    const start = new Date(h.entered_at).getTime();
    const end = h.exited_at ? new Date(h.exited_at).getTime() : Date.now();
    const duration = end - start;
    const key = `${h.order_item_id}_${h.sector}`;

    if (!staysByItem[key]) {
      staysByItem[key] = {
        item: h.order_item || { id: h.order_item_id, name: 'Item Desconhecido' },
        totalDuration: 0,
        sector: h.sector,
        machineName: h.machine?.name || 'Manual / Sem máquina'
      };
    }
    staysByItem[key].totalDuration += duration;
  });

  const longestStays = Object.values(staysByItem)
    .map(stay => ({
      itemId: stay.item.id,
      friendlyId: stay.item.friendly_id || 'PV-???/1',
      itemName: stay.item.name,
      customerName: stay.item.order?.customer?.name || 'Cliente Genérico',
      sector: stay.sector,
      machineName: stay.machineName,
      durationHours: Number((stay.totalDuration / (1000 * 60 * 60)).toFixed(2)),
      durationDays: Number((stay.totalDuration / (1000 * 60 * 60 * 24)).toFixed(2))
    }))
    .sort((a, b) => b.durationHours - a.durationHours)
    .slice(0, 10);

  // 3. Distribuição por Período
  const periodMap: Record<string, { date: string; duration: number; count: number }> = {};
  filtered.forEach(h => {
    const dateStr = new Date(h.entered_at).toLocaleDateString('pt-BR');
    const start = new Date(h.entered_at).getTime();
    const end = h.exited_at ? new Date(h.exited_at).getTime() : Date.now();
    const duration = end - start;

    if (!periodMap[dateStr]) {
      periodMap[dateStr] = { date: dateStr, duration: 0, count: 0 };
    }
    periodMap[dateStr].duration += duration;
    periodMap[dateStr].count += 1;
  });
  const byPeriod = Object.values(periodMap).map(p => ({
    date: p.date,
    averageHours: Number(((p.duration / p.count) / (1000 * 60 * 60)).toFixed(2)),
    count: p.count
  })).slice(0, 30);

  // 4. Distribuição por Cliente
  const customerMap: Record<string, { name: string; duration: number; count: number }> = {};
  filtered.forEach(h => {
    const name = h.order_item?.order?.customer?.name || 'Cliente Genérico';
    const start = new Date(h.entered_at).getTime();
    const end = h.exited_at ? new Date(h.exited_at).getTime() : Date.now();
    const duration = end - start;

    if (!customerMap[name]) {
      customerMap[name] = { name, duration: 0, count: 0 };
    }
    customerMap[name].duration += duration;
    customerMap[name].count += 1;
  });
  const byCustomer = Object.values(customerMap).map(c => ({
    name: c.name,
    averageHours: Number(((c.duration / c.count) / (1000 * 60 * 60)).toFixed(2)),
    count: c.count
  })).sort((a, b) => b.averageHours - a.averageHours);

  // 5. Distribuição por Produto
  const productMap: Record<string, { name: string; duration: number; count: number }> = {};
  filtered.forEach(h => {
    const name = h.order_item?.order?.product?.name || h.order_item?.name || 'Produto Genérico';
    const start = new Date(h.entered_at).getTime();
    const end = h.exited_at ? new Date(h.exited_at).getTime() : Date.now();
    const duration = end - start;

    if (!productMap[name]) {
      productMap[name] = { name, duration: 0, count: 0 };
    }
    productMap[name].duration += duration;
    productMap[name].count += 1;
  });
  const byProduct = Object.values(productMap).map(p => ({
    name: p.name,
    averageHours: Number(((p.duration / p.count) / (1000 * 60 * 60)).toFixed(2)),
    count: p.count
  })).sort((a, b) => b.averageHours - a.averageHours);

  // 6. Distribuição por Máquina
  const machineMap: Record<string, { name: string; duration: number; count: number }> = {};
  filtered.forEach(h => {
    const name = h.machine?.name || 'Manual / Sem máquina';
    const start = new Date(h.entered_at).getTime();
    const end = h.exited_at ? new Date(h.exited_at).getTime() : Date.now();
    const duration = end - start;

    if (!machineMap[name]) {
      machineMap[name] = { name, duration: 0, count: 0 };
    }
    machineMap[name].duration += duration;
    machineMap[name].count += 1;
  });
  const byMachine = Object.values(machineMap).map(m => ({
    name: m.name,
    averageHours: Number(((m.duration / m.count) / (1000 * 60 * 60)).toFixed(2)),
    count: m.count
  })).sort((a, b) => b.averageHours - a.averageHours);

  return {
    data: {
      averageTimes,
      longestStays,
      byPeriod,
      byCustomer,
      byProduct,
      byMachine
    },
    error: null
  };
}

// ─────────────────────────────────────────────────────────────────
// CONFIGURAÇÕES DE TIPOS DE FRETE (SHIPPING TYPES CONFIG)
// ─────────────────────────────────────────────────────────────────

export interface ShippingTypeConfig {
  id: string;
  tenant_id: string;
  name: string;
  status: 'ATIVO' | 'INATIVO';
  created_at: string;
  updated_at: string;
}

let mockShippingTypesConfig: ShippingTypeConfig[] = [
  { id: 'st-01', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Entrega Própria', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'st-02', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Transportadora', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'st-03', tenant_id: 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0', name: 'Retirada na Fábrica', status: 'ATIVO', created_at: new Date().toISOString(), updated_at: new Date().toISOString() }
];

export async function getShippingTypesConfig(tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    const list = mockShippingTypesConfig.filter(s => s.tenant_id === tenantId);
    return { data: list, error: null };
  }

  const { data, error } = await getDbClient()
    .from('shipping_types_config')
    .select('*')
    .eq('tenant_id', tenantId)
    .order('name', { ascending: true });

  return { data, error };
}

export async function createShippingTypeConfig(typeConfig: Omit<ShippingTypeConfig, 'id' | 'created_at' | 'updated_at'>) {
  if (isMockMode) {
    const newConfig: ShippingTypeConfig = {
      ...typeConfig,
      id: Math.random().toString(36).substring(2, 9),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    mockShippingTypesConfig.push(newConfig);
    return { data: newConfig, error: null };
  }

  const { data, error } = await getDbClient()
    .from('shipping_types_config')
    .insert([typeConfig])
    .select()
    .single();

  return { data, error };
}

export async function deleteShippingTypeConfig(id: string) {
  if (isMockMode) {
    mockShippingTypesConfig = mockShippingTypesConfig.filter(s => s.id !== id);
    return { error: null };
  }

  const { error } = await getDbClient()
    .from('shipping_types_config')
    .delete()
    .eq('id', id);

  return { error };
}

// ─────────────────────────────────────────────────────────────────
// OPERAÇÕES: VOLUMES DE EXPEDIÇÃO CONSOLIDADOS (PEDIDO)
// ─────────────────────────────────────────────────────────────────

export interface OrderShippingVolume {
  id: string;
  tenant_id: string;
  order_id: string;
  volume_number: number;
  weight_kg?: number | null;
  width_cm?: number | null;
  height_cm?: number | null;
  length_cm?: number | null;
  packaging_type_id?: string | null;
  notes?: string | null;
  created_at?: string;
  updated_at?: string;
}

let mockOrderShippingVolumes: OrderShippingVolume[] = [];

export async function getOrderShippingVolumes(orderId: string) {
  if (isMockMode) {
    const list = mockOrderShippingVolumes.filter(v => v.order_id === orderId);
    return { data: list, error: null };
  }
  const { data, error } = await getDbClient()
    .from('order_shipping_volumes')
    .select('*, packaging_type:packaging_material_types(*)')
    .eq('order_id', orderId)
    .order('volume_number', { ascending: true });
  return { data: data || [], error };
}

export async function saveOrderShippingVolumes(
  orderId: string, 
  volumes: Omit<OrderShippingVolume, 'id' | 'tenant_id' | 'created_at' | 'updated_at'>[], 
  tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0'
) {
  if (isMockMode) {
    mockOrderShippingVolumes = mockOrderShippingVolumes.filter(v => v.order_id !== orderId);
    for (const v of volumes) {
      mockOrderShippingVolumes.push({
        id: Math.random().toString(36).substring(2),
        tenant_id: tenantId,
        ...v
      });
    }
    return { data: true, error: null };
  }

  // Substituição completa dos volumes do pedido
  await getDbClient()
    .from('order_shipping_volumes')
    .delete()
    .eq('order_id', orderId);

  if (volumes.length === 0) {
    return { data: [], error: null };
  }

  const payload = volumes.map(v => ({
    tenant_id: tenantId,
    order_id: orderId,
    volume_number: v.volume_number,
    weight_kg: v.weight_kg ? Number(v.weight_kg) : null,
    width_cm: v.width_cm ? Number(v.width_cm) : null,
    height_cm: v.height_cm ? Number(v.height_cm) : null,
    length_cm: v.length_cm ? Number(v.length_cm) : null,
    packaging_type_id: v.packaging_type_id || null,
    notes: v.notes || null
  }));

  const { data, error } = await getDbClient()
    .from('order_shipping_volumes')
    .insert(payload)
    .select();

  return { data, error };
}

// Histórico de transições de etapas do Kanban
export async function getOrderItemStageHistory(orderItemId: string) {
  if (isMockMode) {
    return { data: [], error: null };
  }
  const { data, error } = await getDbClient()
    .from('order_item_stage_history')
    .select('*, from_stage:from_stage_id(*), to_stage:to_stage_id(*), changed_by:changed_by_profile_id(*)')
    .eq('order_item_id', orderItemId)
    .order('changed_at', { ascending: true });
  return { data, error };
}

export async function getAllStageHistory(tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    return { data: [], error: null };
  }
  const { data, error } = await getDbClient()
    .from('order_item_stage_history')
    .select('*, from_stage:from_stage_id(*), to_stage:to_stage_id(*), changed_by:changed_by_profile_id(*)')
    .eq('tenant_id', tenantId)
    .order('changed_at', { ascending: true });
  return { data, error };
}

// Histórico de alterações de notas/observações do item
export async function logNotesTransition(
  orderItemId: string,
  notesType: 'OBSERVACOES' | 'ANOTACOES_INTERNAS',
  oldContent: string | null,
  newContent: string | null,
  tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0',
  operatorId?: string | null
) {
  if (isMockMode) {
    return { data: null, error: null };
  }

  const { data, error } = await getDbClient()
    .from('order_item_notes_history')
    .insert([{
      tenant_id: tenantId,
      order_item_id: orderItemId,
      notes_type: notesType,
      old_content: oldContent,
      new_content: newContent,
      operator_id: operatorId || null
    }])
    .select()
    .single();

  return { data, error };
}

export async function getOrderItemNotesHistory(orderItemId: string, tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    return { data: [], error: null };
  }

  const { data, error } = await getDbClient()
    .from('order_item_notes_history')
    .select('*, operator:profiles(*)')
    .eq('order_item_id', orderItemId)
    .eq('tenant_id', tenantId)
    .order('created_at', { ascending: true });

  return { data, error };
}

// --- OPERAÇÕES: REGISTRO DE FALTAS / AVARIAS E LIQUIDAÇÃO NA EXPEDIÇÃO ---

export interface OrderItemShortage {
  id: string;
  tenant_id?: string;
  order_id: string;
  order_item_id: string;
  customer_id?: string;
  shortage_quantity: number;
  reason: string; // 'MANUSEIO_AVARIA', 'PRODUCAO_DEFECT', 'EXTRAVIO', 'DEFEITO_MATERIAL'
  notes?: string;
  reported_by_operator_id?: string;
  reported_by_name?: string;
  reported_at: string;
  status: 'PENDENTE_EXPEDICAO' | 'RESOLVIDO';
  resolution_type?: 'DESCONTO_FATURA' | 'REPOSICAO' | 'ACEITE_PARCIAL';
  resolution_notes?: string;
  resolved_by_operator_id?: string;
  resolved_by_name?: string;
  resolved_at?: string;
  created_at?: string;
}

let mockShortages: OrderItemShortage[] = [];

export async function getOrderItemShortages(orderId?: string, orderItemId?: string, tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (isMockMode) {
    let res = mockShortages;
    if (orderId) res = res.filter(s => s.order_id === orderId);
    if (orderItemId) res = res.filter(s => s.order_item_id === orderItemId);
    return { data: res, error: null };
  }

  try {
    let query = getDbClient()
      .from('order_item_shortages')
      .select('*')
      .eq('tenant_id', tenantId);

    if (orderId) query = query.eq('order_id', orderId);
    if (orderItemId) query = query.eq('order_item_id', orderItemId);

    const { data, error } = await query.order('created_at', { ascending: false });

    if (error) {
      let localData: OrderItemShortage[] = [];
      try {
        const stored = typeof window !== 'undefined' ? localStorage.getItem('samppel_shortages') : null;
        if (stored) localData = JSON.parse(stored);
      } catch (e) {}
      if (orderId) localData = localData.filter(s => s.order_id === orderId);
      if (orderItemId) localData = localData.filter(s => s.order_item_id === orderItemId);
      return { data: localData, error: null };
    }

    return { data: data || [], error: null };
  } catch (err) {
    let localData: OrderItemShortage[] = [];
    try {
      const stored = typeof window !== 'undefined' ? localStorage.getItem('samppel_shortages') : null;
      if (stored) localData = JSON.parse(stored);
    } catch (e) {}
    if (orderId) localData = localData.filter(s => s.order_id === orderId);
    if (orderItemId) localData = localData.filter(s => s.order_item_id === orderItemId);
    return { data: localData, error: null };
  }
}

export async function getOrderItemShortagesBulk(orderItemIds: string[], tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  if (!orderItemIds || orderItemIds.length === 0) {
    return { data: [], error: null };
  }

  try {
    const { data, error } = await getDbClient()
      .from('order_item_shortages')
      .select('*')
      .in('order_item_id', orderItemIds)
      .eq('tenant_id', tenantId);

    if (!error && data) {
      return { data, error: null };
    }
  } catch (err) {}

  let localData: OrderItemShortage[] = [];
  try {
    const stored = typeof window !== 'undefined' ? localStorage.getItem('samppel_shortages') : null;
    if (stored) localData = JSON.parse(stored);
  } catch (e) {}
  return { data: localData.filter(s => orderItemIds.includes(s.order_item_id)), error: null };
}

export async function saveOrderItemShortage(shortage: Partial<OrderItemShortage>, tenantId = 'd3b07384-d113-4ec8-a5c6-e91bc4ff99e0') {
  const newShortage: OrderItemShortage = {
    id: shortage.id || `shortage-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    tenant_id: tenantId,
    order_id: shortage.order_id || '',
    order_item_id: shortage.order_item_id || '',
    customer_id: shortage.customer_id || '',
    shortage_quantity: Number(shortage.shortage_quantity || 0),
    reason: shortage.reason || 'MANUSEIO_AVARIA',
    notes: shortage.notes || '',
    reported_by_operator_id: shortage.reported_by_operator_id || '',
    reported_by_name: shortage.reported_by_name || 'Operador',
    reported_at: shortage.reported_at || new Date().toISOString(),
    status: shortage.status || 'PENDENTE_EXPEDICAO',
    created_at: new Date().toISOString()
  };

  if (isMockMode) {
    mockShortages.push(newShortage);
    return { data: newShortage, error: null };
  }

  try {
    const { data, error } = await getDbClient()
      .from('order_item_shortages')
      .insert([newShortage])
      .select()
      .single();

    if (error) {
      try {
        const stored = typeof window !== 'undefined' ? localStorage.getItem('samppel_shortages') : null;
        const list = stored ? JSON.parse(stored) : [];
        list.push(newShortage);
        if (typeof window !== 'undefined') localStorage.setItem('samppel_shortages', JSON.stringify(list));
      } catch (e) {}
      return { data: newShortage, error: null };
    }

    return { data, error: null };
  } catch (err) {
    try {
      const stored = typeof window !== 'undefined' ? localStorage.getItem('samppel_shortages') : null;
      const list = stored ? JSON.parse(stored) : [];
      list.push(newShortage);
      if (typeof window !== 'undefined') localStorage.setItem('samppel_shortages', JSON.stringify(list));
    } catch (e) {}
    return { data: newShortage, error: null };
  }
}

export async function resolveOrderItemShortage(
  shortageId: string,
  resolution: {
    resolution_type: 'DESCONTO_FATURA' | 'REPOSICAO' | 'ACEITE_PARCIAL';
    resolution_notes?: string;
    resolved_by_operator_id?: string;
    resolved_by_name?: string;
  }
) {
  const patch = {
    status: 'RESOLVIDO' as const,
    resolution_type: resolution.resolution_type,
    resolution_notes: resolution.resolution_notes || '',
    resolved_by_operator_id: resolution.resolved_by_operator_id || '',
    resolved_by_name: resolution.resolved_by_name || 'Expedição',
    resolved_at: new Date().toISOString()
  };

  if (isMockMode) {
    mockShortages = mockShortages.map(s => s.id === shortageId ? { ...s, ...patch } : s);
    return { data: mockShortages.find(s => s.id === shortageId), error: null };
  }

  try {
    const { data, error } = await getDbClient()
      .from('order_item_shortages')
      .update(patch)
      .eq('id', shortageId)
      .select()
      .single();

    if (error) {
      try {
        const stored = typeof window !== 'undefined' ? localStorage.getItem('samppel_shortages') : null;
        let list: OrderItemShortage[] = stored ? JSON.parse(stored) : [];
        list = list.map(s => s.id === shortageId ? { ...s, ...patch } : s);
        if (typeof window !== 'undefined') localStorage.setItem('samppel_shortages', JSON.stringify(list));
      } catch (e) {}
      return { data: { id: shortageId, ...patch }, error: null };
    }

    return { data, error: null };
  } catch (err) {
    try {
      const stored = typeof window !== 'undefined' ? localStorage.getItem('samppel_shortages') : null;
      let list: OrderItemShortage[] = stored ? JSON.parse(stored) : [];
      list = list.map(s => s.id === shortageId ? { ...s, ...patch } : s);
      if (typeof window !== 'undefined') localStorage.setItem('samppel_shortages', JSON.stringify(list));
    } catch (e) {}
    return { data: { id: shortageId, ...patch }, error: null };
  }
}



